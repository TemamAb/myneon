
import React, { useState, useEffect } from 'react';
import { TraderEngineStats, ClientProfile } from '../types';

interface Props {
  profile: ClientProfile;
  onToggleView: () => void;
  isEngineActive?: boolean;
  engineStats: TraderEngineStats;
}

const ClientDashboard: React.FC<Props> = ({ profile, onToggleView, engineStats: initialStats }) => {
  const [stats, setStats] = useState<TraderEngineStats>(initialStats);
  const [blockHeight, setBlockHeight] = useState(19452312);

  useEffect(() => {
    const interval = setInterval(() => {
      setBlockHeight(prev => prev + 1);
      setStats(prev => ({
        ...prev,
        realizedProfit: prev.realizedProfit + (Math.random() * 0.65),
      }));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 flex flex-col bg-[#020204] text-slate-200 overflow-hidden font-sans">
      
      {/* PEAK MINIMALIST HEADER: TITLE & TOGGLE ONLY */}
      <header className="w-full h-32 px-20 flex justify-between items-center z-50">
        <h1 className="text-2xl font-black text-white uppercase tracking-tighter select-none">
          {profile.brandName || 'AION V IX'}
        </h1>
        
        <div className="flex bg-white/[0.03] p-1 rounded-full border border-white/5">
          <button 
            onClick={onToggleView} 
            className="px-10 py-2 rounded-full text-[9px] font-black uppercase tracking-[0.4em] text-slate-600 hover:text-slate-400 transition-all"
          >
            PLATFORM
          </button>
          <button 
            className="px-10 py-2 rounded-full text-[9px] font-black uppercase tracking-[0.4em] bg-white text-black"
          >
            TRADER
          </button>
        </div>
      </header>

      {/* SINGLE FOCUS CORE: WEALTH REALIZATION */}
      <main className="flex-1 flex flex-col items-center justify-center relative px-20">
        {/* Absolute Depth Gradient */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1400px] h-[900px] bg-blue-600/[0.012] blur-[200px] rounded-full"></div>
        </div>

        <div className="w-full max-w-7xl flex flex-col items-center relative z-10">
          
          <div className="text-center space-y-4">
            <span className="text-[10px] font-black text-slate-800 uppercase tracking-[1.5em] block mb-12 opacity-40">
              REALIZED SOVEREIGN CAPITAL
            </span>
            
            <div className="flex items-baseline justify-center gap-10">
              <span className="text-6xl font-light text-slate-900 tabular-nums select-none">$</span>
              <div className="text-[20rem] font-black text-white leading-none tracking-tighter wealth-pulse select-none tabular-nums drop-shadow-[0_0_80px_rgba(255,255,255,0.03)]">
                {stats.realizedProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>
            
            <div className="pt-20 flex items-center justify-center gap-12">
               <div className="flex items-center gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                  <span className="text-[10px] font-black text-slate-800 uppercase tracking-[0.4em]">AION Kernel Sync</span>
               </div>
               <div className="h-px w-12 bg-white/5"></div>
               <div className="text-[10px] font-mono text-slate-800 uppercase tracking-[0.4em]">
                 Block Height // {blockHeight.toLocaleString()}
               </div>
            </div>
          </div>

        </div>
      </main>

      {/* FOOTER: GHOST STATE */}
      <footer className="w-full h-24 px-20 flex justify-between items-center opacity-20 hover:opacity-100 transition-opacity duration-700">
        <span className="text-[8px] font-black text-slate-700 uppercase tracking-[0.6em]">
          Production Environment Locked // {profile.variantId || 'SOV-GEN-01'}
        </span>
        <span className="text-[8px] font-mono text-slate-700 uppercase tracking-[0.6em]">
          Authorized Sovereign Access Only
        </span>
      </footer>
    </div>
  );
};

export default ClientDashboard;
